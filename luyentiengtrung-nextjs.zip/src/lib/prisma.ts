import { PrismaClient } from "@prisma/client";

// Tránh tạo nhiều instance PrismaClient khi Next.js hot-reload ở dev mode
const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
