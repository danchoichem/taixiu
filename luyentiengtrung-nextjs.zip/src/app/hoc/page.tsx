import { redirect } from "next/navigation";
import { auth } from "@/auth";
import DangXuatButton from "@/components/DangXuatButton";

export default async function HocPage() {
  const session = await auth();

  if (!session?.user) {
    redirect("/dang-nhap");
  }

  return (
    <main className="mx-auto max-w-2xl px-4 py-10">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold">
          Xin chào, {session.user.name ?? session.user.email}!
        </h1>
        <DangXuatButton />
      </div>
      <p>Đây là trang học — chỉ người đã đăng nhập mới xem được.</p>
      {/* TODO: chuyển nội dung học tiếng Trung (từ vựng, TTS, sidebar...) vào đây */}
    </main>
  );
}
