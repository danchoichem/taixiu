import Link from "next/link";
import { auth } from "@/auth";

export default async function Home() {
  const session = await auth();

  return (
    <main className="mx-auto flex min-h-screen max-w-2xl flex-col items-center justify-center gap-6 px-4 text-center">
      <h1 className="text-3xl font-bold">Luyện Tiếng Trung 🇨🇳</h1>
      <p className="text-gray-600">
        Học từ vựng, phát âm và ngữ pháp tiếng Trung mỗi ngày.
      </p>

      {session?.user ? (
        <Link href="/hoc" className="rounded bg-black px-4 py-2 text-white">
          Vào học ngay
        </Link>
      ) : (
        <div className="flex gap-3">
          <Link href="/dang-nhap" className="rounded border px-4 py-2">
            Đăng nhập
          </Link>
          <Link href="/dang-ky" className="rounded bg-black px-4 py-2 text-white">
            Đăng ký
          </Link>
        </div>
      )}
    </main>
  );
}
