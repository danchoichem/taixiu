export { auth as middleware } from "@/auth";

export const config = {
  // Chỉ áp dụng middleware (kiểm tra đăng nhập) cho các route bắt đầu bằng /hoc
  matcher: ["/hoc/:path*"],
};
