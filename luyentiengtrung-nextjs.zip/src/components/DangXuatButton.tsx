"use client";

import { signOut } from "next-auth/react";

export default function DangXuatButton() {
  return (
    <button
      onClick={() => signOut({ callbackUrl: "/" })}
      className="rounded border px-3 py-1 text-sm"
    >
      Đăng xuất
    </button>
  );
}
